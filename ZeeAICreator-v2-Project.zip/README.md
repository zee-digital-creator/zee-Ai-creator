# Zee AI Creator v2

Android starter project for a monetizable AI creator app.

## Included
- Polished mobile home screen
- AI image prompt workflow
- Short video script workflow
- Premium screen
- Earning explanation
- AdMob placement placeholder

## Before Play Store release
- Connect a real AI image/video API
- Replace the ad placeholder with your own AdMob App ID/ad unit IDs
- Add a real payment/subscription provider if desired
- Add Privacy Policy and Terms pages
- Test on multiple Android devices
- Build a signed Android App Bundle (.aab)

This starter does not claim guaranteed earnings.
