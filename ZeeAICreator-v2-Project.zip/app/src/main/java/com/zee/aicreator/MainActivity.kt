package com.zee.aicreator

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun bg(color: Int = Color.WHITE) = GradientDrawable().apply {
        setColor(color); cornerRadius = 28f
    }

    private fun button(text: String, click: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 16f
            setOnClickListener { click() }
            background = bg(Color.rgb(30, 64, 175))
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(-1, 58).apply { setMargins(0, 10, 0, 10) }
        }

    private fun showHome() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
            setBackgroundColor(Color.rgb(248,250,252))
        }

        val title = TextView(this).apply {
            text = "✨ Zee AI Creator"
            textSize = 30f; setTextColor(Color.rgb(17,24,39))
            gravity = Gravity.CENTER
        }
        box.addView(title, LinearLayout.LayoutParams(-1, 70))

        val sub = TextView(this).apply {
            text = "Create ideas, images & short videos from your phone"
            textSize = 16f; gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
        }
        box.addView(sub, LinearLayout.LayoutParams(-1, 70))

        box.addView(button("🖼️ AI Image Prompt", ::imagePrompt))
        box.addView(button("🎬 Short Video Script", ::videoScript))
        box.addView(button("⭐ Premium / Remove Ads", ::premium))
        box.addView(button("💰 How Zee AI Creator Earns", ::earningInfo))

        result = TextView(this).apply {
            text = "Your generated result will appear here."
            textSize = 17f; setTextColor(Color.rgb(31,41,55))
            setPadding(20, 20, 20, 20)
            background = bg(Color.WHITE)
        }
        box.addView(result, LinearLayout.LayoutParams(-1, 260).apply { setMargins(0,20,0,0) })

        val ad = TextView(this).apply {
            text = "Advertisement • AdMob placement"
            gravity = Gravity.CENTER
            setTextColor(Color.GRAY)
            textSize = 13f
        }
        box.addView(ad, LinearLayout.LayoutParams(-1, 55))

        scroll.addView(box)
        setContentView(scroll)
    }

    private fun imagePrompt() {
        val input = EditText(this).apply { hint = "Example: cute rabbit in a forest" }
        AlertDialogHelper.show(this, "AI Image", input) {
            val text = input.text.toString().ifBlank { "cute rabbit in a magical forest" }
            result.text = "IMAGE PROMPT\n\nCreate a high-quality children's illustration of: $text\n\nStyle: colorful, friendly, detailed, cinematic lighting."
        }
    }

    private fun videoScript() {
        val input = EditText(this).apply { hint = "Example: smart rabbit and lion" }
        AlertDialogHelper.show(this, "Short Video", input) {
            val text = input.text.toString().ifBlank { "smart rabbit and lion" }
            result.text = "VIDEO SCRIPT\n\nScene 1: Introduce $text.\nScene 2: A problem appears.\nScene 3: The hero uses a clever idea.\nScene 4: Happy ending + moral.\n\nMoral: Wisdom and courage can solve difficult problems."
        }
    }

    private fun premium() {
        result.text = "PREMIUM PLAN\n\n• Ad-free experience\n• Higher AI limits\n• Premium templates\n• Faster generation\n\nPayment gateway can be connected after the business/payment account is ready."
    }

    private fun earningInfo() {
        result.text = "EARNING MODEL\n\n1. AdMob advertisements\n2. Optional premium subscription\n3. Optional paid AI credits\n\nImportant: earnings are not guaranteed and depend on users, ad views, country, retention and platform policies."
    }
}

object AlertDialogHelper {
    fun show(a: Activity, title: String, input: EditText, onGo: () -> Unit) {
        android.app.AlertDialog.Builder(a)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("Create") { _, _ -> onGo() }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
